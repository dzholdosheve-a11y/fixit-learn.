const toast = document.getElementById('toast');
let toastTimer;
function showToast(message) {
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 2300);
}

document.querySelectorAll('.nav-link').forEach(button => {
  button.addEventListener('click', () => {
    document.querySelectorAll('.nav-link').forEach(item => item.classList.remove('active'));
    button.classList.add('active');
    document.getElementById('page-title').textContent = button.dataset.page;
    if (button.dataset.page !== 'Главная') {
      showToast(`Раздел «${button.dataset.page}» выбран — демо-версия`);
    }
  });
});

document.querySelectorAll('[data-goto]').forEach(button => {
  button.addEventListener('click', () => {
    const target = button.dataset.goto;
    const navButton = [...document.querySelectorAll('.nav-link')].find(item => item.dataset.page === target);
    if (navButton) navButton.click();
  });
});

document.getElementById('continue-btn').addEventListener('click', () => {
  showToast('Отлично! Продолжаем обучение 🚀');
});

document.querySelectorAll('.course-btn').forEach(button => {
  button.addEventListener('click', () => {
    const title = button.closest('.course-card').querySelector('h3').textContent;
    showToast(`Открываем курс «${title}»`);
  });
});

document.querySelectorAll('.task input').forEach(input => {
  input.addEventListener('change', () => {
    const taskName = input.parentElement.querySelector('b').textContent;
    input.parentElement.classList.toggle('completed', input.checked);
    showToast(input.checked ? `Задание выполнено: ${taskName}` : 'Задание возвращено в список');
  });
});

document.getElementById('search-input').addEventListener('input', event => {
  const query = event.target.value.toLowerCase().trim();
  document.querySelectorAll('.course-card').forEach(card => {
    card.style.display = card.dataset.course.toLowerCase().includes(query) ? '' : 'none';
  });
});
